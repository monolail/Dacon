import os
import pandas as pd
import lightgbm as lgb
import joblib

def main():
    # 데이콘 채점 서버 경로 규칙 (절대 수정 금지)
    TEST_PATH = "./data/test.csv"
    SUB_PATH = "./data/sample_submission.csv"
    MODEL_PATH = "./model/lgb_model.txt"
    ENCODER_PATH = "./model/encoders.pkl"
    PROFILE_PATH = "./model/pitcher_profile.csv"
    FEATURES_PATH = "./model/final_features.pkl"
    OUT_PATH = "./output/submission.csv"

    # 저장해둔 모델 및 기준표 불러오기
    model = lgb.Booster(model_file=MODEL_PATH)
    label_encoders = joblib.load(ENCODER_PATH)
    pitcher_profile = pd.read_csv(PROFILE_PATH)
    final_features = joblib.load(FEATURES_PATH)

    test = pd.read_csv(TEST_PATH)
    sub = pd.read_csv(SUB_PATH)

    # [1] Label Encoding
    categorical_cols = ['top_bottom', 'pitcher_hand', 'batter_hand', 'game_type', 'base_state']
    for col in categorical_cols:
        le = label_encoders[col]
        # 처음 보는 값이 나오면 에러가 나지 않도록 첫 번째 값으로 우회 (안전장치)
        test[col] = test[col].astype(str).apply(lambda x: x if x in le.classes_ else le.classes_[0])
        test[col] = le.transform(test[col])

    # [2] 파생 변수(볼카운트/득점권/짬바) 생성
    test['is_pitcher_behind'] = (test['balls_before'] > test['strikes_before']).astype(int)
    test['is_full_count'] = ((test['balls_before'] == 3) & (test['strikes_before'] == 2)).astype(int)
    test['is_clutch'] = ((test['inning'] >= 7) & (test['score_diff_home'].abs() <= 1)).astype(int)
    test['is_garbage_time'] = (test['score_diff_home'].abs() >= 7).astype(int)
    test['experience_diff'] = test['asof_pitcher_n'] - test['asof_batter_n']

    # [3] 트랙맨 프로필 병합
    test = pd.merge(test, pitcher_profile, on='pitcher_id', how='left')

    # [4] 정답 예측
    X_test = test[final_features]
    preds = model.predict(X_test)

    # [5] 예측 결과 저장
    sub['control_success'] = preds
    os.makedirs(os.path.dirname(OUT_PATH), exist_ok=True)
    sub.to_csv(OUT_PATH, index=False)

if __name__ == "__main__":
    main()
